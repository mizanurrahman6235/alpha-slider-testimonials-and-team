css dynamic
js dynamic
logo dynamic
header backgound dynamic
text color dynamic 
===================
title and tagline dynamic
site url dynamic
====================
post-title, author, date, tag-list dynamic
featured image/thumbnail image and content or excerpt dynamic
====================
sidebar and footer dynamic
top menu and footer menu dynamic

<div class="container">
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h1>Contact Us</h1>
			[contact-form-7 id="110" title="Contact form 1"]
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h1>Naser Foundation</h1>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.8914170186586!2d89.21150721445586!3d23.751251194661894!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39feed2f3407dc2f%3A0xfe3806ad375db0ea!2sNaser%20Foundation!5e0!3m2!1sen!2sbd!4v1606018333210!5m2!1sen!2sbd" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
		</div>
	</div>
</div>

<?php
	function alpha_assets(){
		//css dynamic
		wp_enqueue_style("bootstrap", get_theme_file_uri("/assets/css/bootstrap.min.css"));
		wp_enqueue_style("animate", get_theme_file_uri("/assets/css/animate.css"));
		wp_enqueue_style("fontawesome", get_theme_file_uri("/assets/css/fontawesome.min.css"));
		wp_enqueue_style("style", get_stylesheet_uri());
		
		wp_enqueue_script("bootstrap-jquery-js",get_theme_file_uri("/assets/css/fontawesome.min.js"),array(""),"1.0",true);
	}
	add_acton("wp_enqueue_scripts","alpha_assets");
?>

<?php the_title(); ?>
<?php the_author(); ?>
<?php echo get_the_date(); ?>
<?php echo get_the_tag_list(); ?>

<?php
	if(has_post_thumbnail){
		the_post_thumbnail("large", array("class"=>"img-fluid") );
	}
	the_content();
?>